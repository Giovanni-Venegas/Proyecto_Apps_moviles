package informatico.to.log_inapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Dash extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash);
    }
    public void tudo (View v){
        Intent intento1 = new Intent (this, tudo_bem.class);
        startActivity(intento1);
    }
    public void contacto (View v){
        Intent intento2 = new Intent (this, emergencia.class);
        startActivity(intento2);
    }


    public void preferencia (View v){
        Intent intentox = new Intent (this, Maps.class);
        startActivity(intentox);
    }
}